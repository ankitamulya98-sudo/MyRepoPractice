package Assignment2;

class Device_A
{
	void start()
	{
		System.out.println("Device is starting");
	}
}

class mobile extends Device_A
{
	void calling()
	{
		System.out.println("Device is calling");
	}
}

class SmartPhone extends mobile
{
	void internet()
	{
		System.out.println("Internet switched on in the device");
	}
}

public class Multilevel_Inheritance {

	public static void main(String[] args) {
		SmartPhone obj = new SmartPhone();
		obj.start();
		obj.calling();
		obj.internet();
		
		

	}

}
