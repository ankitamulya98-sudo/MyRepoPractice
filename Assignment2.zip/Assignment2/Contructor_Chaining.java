package Assignment2;

class Mall
{
	Mall()
	{
		System.out.println("Welcome to the Mall");
	}
	Mall(String mallname)
	{
		this();
		System.out.println("Mall name: "+mallname);
	}
}

public class Contructor_Chaining {

	public static void main(String[] args) {
		Mall obj = new Mall("City Center Mall");

	}

}
