package Assignment2;

class GovernmentRules 
{
    final int MAX_WORKING_HOURS = 8;
}

public class finalkeyword_contants {

	public static void main(String[] args) {
		GovernmentRules rule = new GovernmentRules();
        System.out.println("Maximum Working Hours: " + rule.MAX_WORKING_HOURS);
        // Trying to modify a final variable
        // rule.MAX_WORKING_HOURS = 10;  // Compile-time Error

	}

}
