package Assignment2;

abstract class Animal
{
	abstract void sound();
}

class Dog extends Animal
{
	void sound()
	{
		System.out.println("Dog Barks");
	}
}

class Cat extends Animal
{
	void sound()
	{
		System.out.println("Cat Meows");
	}
}

public class Abstraction {

	public static void main(String[] args) {
		Dog obj = new Dog();
		obj.sound();
		
		Cat obj1 = new Cat();
		obj1.sound();

	}

}
