package Assignment2;

class Hospital
{
	void emergencyservice()
	{
		System.out.println("Emergency service is available here 24/7");
	}
}

class CityHospital extends Hospital
{
	void emergencyservice()
	{
		super.emergencyservice();
		System.out.println("Emergency service available with Doctors and ambulance 24/7");
	}
}

public class MethodOverridingwithsuper {

	public static void main(String[] args) {
		CityHospital obj = new CityHospital();
		obj.emergencyservice();

	}

}
