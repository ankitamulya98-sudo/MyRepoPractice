package Assignment2;

class Student1
{
	static String collegeName = "St. Aloysiuos";
	int rollno;
	String name;
	
	Student1(int id, String n)
	{
		rollno = id;
		name = n;
	}
	
	void displaystudentsDetails()
	{
		System.out.println("Student ID: "+rollno);
		System.out.println("Student Name: "+name);
		System.out.println("College Name: "+collegeName);
		System.out.println();
	}
}

public class StaticKeyword {

	public static void main(String[] args) {
		Student1 obj = new Student1(1111, "Ankita Mulya");
		Student1 obj1 = new Student1(1112, "Tina Agarwal");
		Student1 obj2 = new Student1(1113, "Ramyashree Karnath");
		Student1 obj3 = new Student1(1114, "Mohan Patel");
		
		obj.displaystudentsDetails();
		obj1.displaystudentsDetails();
		obj2.displaystudentsDetails();
		obj3.displaystudentsDetails();
		
	}

}
