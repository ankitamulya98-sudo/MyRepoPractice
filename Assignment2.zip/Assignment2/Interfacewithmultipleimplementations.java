package Assignment2;

interface Transport
{
	void bookings();
}

class Bus implements Transport
{
	public void bookings()
	{
		System.out.println("Bus Booking Status: Bus bookings for Mumbai to Karnataka will start from 1st NOv 2026");
	}
}

class Flight implements Transport
{
	public void bookings()
	{
		System.out.println("Flight Booking Status: Flight bookings for tatkal will start from morning 11 AM");
	}
}

public class Interfacewithmultipleimplementations {

	public static void main(String[] args) {
		Transport ref = new Bus();
		ref.bookings();
		
		Transport ref1 = new Flight();
		ref1.bookings();

	}

}
