package Assignment2;

class University
{
	 static String country = "India";
	  String universityName;

	    University(String universityName) {
	        this.universityName = universityName;
	    }

	    void display() {
	        System.out.println("University Name: " + universityName);
	        System.out.println("Country: " + country);
	        System.out.println();
	    }
}

public class staticconcept {

	public static void main(String[] args) {
		 University u1 = new University("Manglore University");
	     University u2 = new University("Gujarat University");
	     u1.display();
	     u2.display();

	}

}
