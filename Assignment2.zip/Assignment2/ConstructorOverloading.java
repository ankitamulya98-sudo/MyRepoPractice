package Assignment2;

class Product
{
	int productId;
	String productName;
	double price;
	
	Product()
	{
		System.out.println("Product Created");
	}
	
	Product(int id, String name, double pr)
	{
		productId = id;
		productName = name;
		price = pr;
	}
	
	void displayProduct()
	{
		System.out.println("Product ID: " +productId);
		System.out.println("Product Name: "+productName);
		System.out.println("Price: "+price);
	}
}

public class ConstructorOverloading {

	public static void main(String[] args) {
		Product obj = new Product();
		obj.displayProduct();
		
		Product obj1 = new Product(1121, "Samsung S26 Ultra", 600000);
		obj1.displayProduct();
	}

}
