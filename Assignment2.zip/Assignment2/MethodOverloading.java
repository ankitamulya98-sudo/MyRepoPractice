package Assignment2;

class Calculator
{
	int add(int a, int b)
	{
		return a+b;
	}
	double add(double a, double b)
	{
		return a+b;
	}
}

public class MethodOverloading {

	public static void main(String[] args) {
		Calculator obj = new Calculator();
		System.out.println("**** Calculator****");
		System.out.println("Addition of int variables");
		System.out.println(obj.add(12, 20));
		System.out.println("Addition of double variables");
		System.out.println(obj.add(49.23, 34.12));

	}

}
