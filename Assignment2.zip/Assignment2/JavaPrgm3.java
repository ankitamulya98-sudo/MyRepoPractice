package Assignment2;

class schools
{
	int strength;
	String name, address;
	
	schools(int st, String n)
	{
		strength = st;
		name = n;
	}
	
	schools(String n, String add, int st)
	{
		strength = st;
		name = n;
		address = add;
		
	}
	
	void display()
	{
		System.out.println("****School Details****");
		System.out.println("Name: "+name);
		System.out.println("Address: "+address);
		System.out.println("Strength: "+strength);
	}
}

public class JavaPrgm3 {

	public static void main(String[] args) {
		schools obj = new schools("Shantaba English Medium School", "Vapi, Gujarat", 10002);
		obj.display();

	}

}
