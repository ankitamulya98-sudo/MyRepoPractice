package Assignment2;

class Account
{
	private String accountHolderName;
	private double balance;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		
		if(balance < 0)
		{
			System.out.println("Warning: Balance cannot be negative");
		}
		else
		{
			this.balance = balance;
		}
		
	}	
}

public class Encapsulation_Validationlogic {

	public static void main(String[] args) {
		Account obj = new Account();
		obj.setAccountHolderName("John Bell");
		System.out.println("AccountHolder Name: " +obj.getAccountHolderName());
		obj.setBalance(200000.00);
		System.out.println("Balance: " +obj.getBalance());
		obj.setBalance(-100);
		

	}

}
