package Assignment2;

abstract class Employe
{
	
	abstract void calculateSalary();
	
	void employeeDetails(String ename)
	{
		System.out.println("Employee Name: "+ename);
	}
}

class FullTimeEmployee extends Employe
{
	void calculateSalary()
	{
		int monthlySalary = 50000;
		System.out.println("FullTime salary: "+monthlySalary);
	}
}

class PartTimeEmployee extends Employe
{
	void calculateSalary()
	{
		int hoursworked = 20;
		int hourlyRate = 5000;
		System.out.println("PartTimeSalary: "+hoursworked*hourlyRate);
	}
}
public class Abstactclass_Realusage {

	public static void main(String[] args) {
		Employe ref = new FullTimeEmployee();
		ref.employeeDetails("Abhinav Mishra");
		ref.calculateSalary();
		System.out.println();
		Employe ref1 = new PartTimeEmployee();
		ref1.employeeDetails("Vikas Sharma");
		ref1.calculateSalary();

	}

}
