package Assignment2;

class LoanCalculator
{
	void calculateLoan(int amount)
	{
		System.out.println("Loan amount: "+amount);
	}

	void calculateLoan(int amount, double interestRate)
	{
		double res = amount * interestRate; 
		System.out.println("Loan amount after adding Intrest Rate: "+res);
	}
}

public class MethodOverloading_BankScenario {

	public static void main(String[] args) {
		LoanCalculator obj = new LoanCalculator();
		obj.calculateLoan(500000);
		obj.calculateLoan(5000000, 2.3);

	}

}
