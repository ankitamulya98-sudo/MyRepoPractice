package Assignment2;

class Person
{
	Person()
	{
		System.out.println("Person Created");
	}
}

class Student extends Person
{	
	Student()
	{	
		super();
		System.out.println("Student Created");
	}
	
}

public class superKeyword {

	public static void main(String[] args) {
		Student obj = new Student();
	}

}
