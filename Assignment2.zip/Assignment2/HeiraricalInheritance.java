package Assignment2;

class Course
{
	void courseInfo()
	{
		System.out.println("Here are the details of the couse provided on our academy");
	}
}

class Science extends Course
{
	void displayscience()
	{
		System.out.println("1. Science");
		System.out.println();
	}
}

class Commerce extends Course
{
	void displaycommerce()
	{
		System.out.println("2. Commerce");
		System.out.println();
	}
}

class Arts extends Course
{
	void displayarts()
	{
		System.out.println("3. Arts");
		System.out.println();
	}
}
public class HeiraricalInheritance {

	public static void main(String[] args) {
		Science obj = new Science();
		obj.courseInfo();
		obj.displayscience();
		
		Commerce obj1 = new Commerce();
		obj1.courseInfo();
		obj1.displaycommerce();
		
		Arts obj2 = new Arts();
		obj2.courseInfo();
		obj2.displayarts();
		
		

	}

}
