package Assignment2;

class Shape
{
	void area() {
		System.out.println("Area of Shapes...");
	}
}

class Rectangle extends Shape
{
	void area()
	{
		int l = 10;
		int w = 5;
		int result = l*w;
		System.out.println("Area of Rectangle: " +result);
	}
}

class Circle extends Shape
{
	void area()
	{
		double r =3;
		double result = 3.14*r*r;
		System.out.println("Area of Circle: "+result);
		
	}
}

public class Polymorphism {

	public static void main(String[] args) {
		Shape ref = new Rectangle();
		ref.area();
		
		Shape ref1 = new Circle();
		ref1.area();
	}

}
