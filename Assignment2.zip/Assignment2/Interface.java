package Assignment2;

interface Payment
{
	default void test()
	{
		System.out.println("Payment Options available here....");
	}
	void makepayment();
}

class UPI implements Payment
{
	public void makepayment()
	{
		System.out.println("Payment done successfully using UPI");
	}
}

class CreditCard implements Payment
{
	public void makepayment()
	{
		System.out.println("Payment done successfully using CreditCard");
	}
}

public class Interface {

	public static void main(String[] args) {
		Payment ref = new UPI();
		ref.makepayment();
		
		Payment ref1 = new CreditCard();
		ref1.makepayment();
	}

}
