package Assignment2;

class Camera
{
	void capture()
	{
		System.out.println("camera captures natural photos");
	}
}

class DSLcamera extends Camera
{
	void capture()
	{
		System.out.println("Capturing high-quality photo using DSLR Camera");
	}
}

public class Polymorphism_runtime_upcasting {

	public static void main(String[] args) {
		Camera ref = new DSLcamera();
		ref.capture();
	}

}
