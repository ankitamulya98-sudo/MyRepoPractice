package Assignment2;

class Shapes
{
	int length;
	
	int square(int l)
	{
		length = l;
		return l*l;
		
	}
	
	int rectangle(int l, int w)
	{
		length = l;
		return l*w;
	}
	
	double circle(int r)
	{
		return 3.14*r*r;
	}
}

public class JavaPrgm1 {

	public static void main(String[] args) {
		Shapes obj = new Shapes();
		System.out.println("Area of Square: "+obj.square(5));
		System.out.println("Area of Rectangle: "+obj.rectangle(9, 4));
		System.out.println("Area of Circle: "+obj.circle(10));

	}
}
