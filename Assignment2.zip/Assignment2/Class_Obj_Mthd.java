package Assignment2;

class Library
{
	String libraryName;
	
	Library()
	{
		System.out.println("Welcome to Library!");
	}
	
	void showlocation()
	{
		System.out.println("This library is located in Mumbai");
	}
}
public class Class_Obj_Mthd {

	public static void main(String[] args) {
		Library obj = new Library();
		obj.showlocation();

	}

}
