package Assignment2;

class Employee
{
	private int empId;
	private String empName;
	private double salary;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	void displayDetails()
	{
		System.out.println("Employee Id: " +empId);
		System.out.println("Employee Name: " +empName);
		System.out.println("Salary: " +salary);
	}	
}

public class Encapsulation {

	public static void main(String[] args) {
		
		Employee obj = new Employee();
		obj.setEmpId(1120);
		obj.setEmpName("Ankita Mulya");;
		obj.setSalary(2000000);

		

	}

}
