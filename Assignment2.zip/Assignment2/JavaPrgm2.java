package Assignment2;

class school
{
	String name;
	
	school()
	{
		System.out.println("Shantaba English Medium School");
	}
	
	void location()
	{
		System.out.println("This School is based out at Kolkata");
	}
}

public class JavaPrgm2 {

	public static void main(String[] args) {
		school obj = new school();
		obj.location();

	}

}
