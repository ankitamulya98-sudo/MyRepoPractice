package Assignment2;

class Bank
{
	final String IFSC = "RBIC134800";
	
	final void showIFSC()
	{
		System.out.println("IFSC code: "+IFSC);
	}
	
}

class HDFCBank extends Bank
{
	//void showIFSC()
	//{
		//System.out.println("New IFSC Code: HDFC110998101011");
	//}
	
}

public class Final {

	public static void main(String[] args) {
		HDFCBank obj = new HDFCBank();
		obj.showIFSC();

	}

}
