package Assignment2;

class Engine 
{
    void engineInfo() 
    {
        System.out.println("Engine: 1100cc Petrol Engine");
    }
}

class Car 
{
    Engine engine;

    Car(Engine engine) 
    {
        this.engine = engine;
    }

    void showCarDetails() 
    {
        System.out.println("Car Details:");
        engine.engineInfo();
    }
}

public class Aggregation {

    public static void main(String[] args) {
        Engine eng = new Engine();
        Car car = new Car(eng);
        car.showCarDetails();
    }
}