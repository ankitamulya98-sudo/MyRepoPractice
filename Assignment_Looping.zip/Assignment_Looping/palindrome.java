package Assignment_Looping;

public class palindrome {

	public static void main(String[] args) {
		int num = 121;
		int n=num;
		int rev=0;
		
		while(num!=0)
		{
			int d=num%10;
			rev=rev*10+d;
			num=num/10;
		}
		System.out.println("Reverse number is: "+rev);
		
		if(n==rev)
		{
			System.out.println("Its a palindrome number");
		}
		else
		{
			System.out.println("Its not a palindrome number");
		}

	}

}
