package Assignment_Looping;

public class countdigit {

	public static void main(String[] args) {
		int num = 98765;
		
		int count=0;
		
		while(num!=0) 
		{
			num=num/10;
			count++;
		}
		System.out.println("Number of digit is: "+count);
	}

}
