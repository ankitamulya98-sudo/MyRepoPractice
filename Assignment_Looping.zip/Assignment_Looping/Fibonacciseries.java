package Assignment_Looping;

import java.util.Scanner;

public class Fibonacciseries {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int count;
		System.out.println("Enter a number:");
		count = sc.nextInt();
		
		int i=1;
		int n1=0;
		int n2=1;
		int n3;
		
		do
		{
			System.out.println(n1 + " ");
			n3=n1+n2;
			n1=n2;
			n2=n3;
			i++;
			
		}
		while(i<=count);
		
	}

}
