package Assignment_Looping;

public class primenumcheck {

	public static void main(String[] args) {
		int num=11;
		Boolean isPrime=true;
		
		for (int i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				isPrime=false;
				break;
			}
		}
		System.out.println(isPrime? "Prime":"Not Prime");

	}

}
