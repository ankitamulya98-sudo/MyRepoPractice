package Assignment_Looping;

public class LargestofThreenum {

	public static void main(String[] args) {
		int a= 10, b=25, c=15;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("Max is: "+a);
			}
			else
			{
				System.out.println("Max is: "+c);
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("Max is: "+b);
			}
			else
			{
				System.out.println("Max is: "+c);
			}
		}
	}

}
